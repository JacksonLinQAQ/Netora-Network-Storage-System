import json
import shutil
import os
import sys
import zipfile
import time
import locale

default_encoding = locale.getpreferredencoding()

P_FILE = 'file'
P_FOLDER = 'folder'
P_ROOT = 'root'

class Zip:
    def __init__(self, finder:"Finder", user:str, path:str, is_public:bool=False) -> None:
        self.user = user
        self.path = path
        self.finder = finder
        self.is_public = is_public
        if is_public:
            self.user = None
            self.rootpath = './Netora/Storage/Public'
            self.location = ('/'.join(self.path.split('/')[:-1])).strip('/')
        else:
            self.user = user
            self.rootpath = './Netora/Storage/Personal/' + self.user
            self.location = ('/'.join(self.path.split('/')[:-1])).strip('/')
        
        self.fullpath = self.rootpath + '/' + self.path
		

    def extract(self):
        # 對壓縮檔解壓縮
        with zipfile.ZipFile(self.fullpath, 'r') as zip_obj:
            dst_path = '/'.join(self.path.split('/')[:-1]).strip('/').strip('/')
            dst_fullpath = '/'.join(self.fullpath.split('/')[:-1]).strip('/')
            zip_folder_name = zip_obj.namelist()[0].split('/')[0].strip('/')
            zip_folder_fullpath = dst_fullpath + '/' + zip_folder_name.strip('/')
            if self.is_public:
                find = self.finder.findPublicByPath
            else:
                find = self.finder.findPersonalByPath

            os.makedirs(zip_folder_fullpath, exist_ok=True)
            find(dst_path).add_data(Folder(
                self.finder, 
                self.user, 
                zip_folder_name,
                dst_path + '/' + zip_folder_name,
                {},
                self.is_public
            ))

            namelist = zip_obj.namelist()
            zipinfo = zip_obj.infolist()
            for member in zipinfo:
                member.filename = member.filename.encode('cp437').decode(default_encoding)
        
                zip_obj.extract(member, dst_fullpath)

            for f in namelist:
                dst = '/'.join(f.strip('/').split('/')[:-1]).strip('/')
                
                file = f.strip('/').split('/')[-1].encode('cp437').decode(default_encoding)
                
                if zip_obj.getinfo(f).is_dir():
                    find(dst_path + '/' + dst).add_data(Folder(self.finder, self.user, file, dst_path + '/' + dst + '/' + file, {}, self.is_public))
                else:
                    find(dst_path + '/' + dst).add_data(File(self.finder, self.user, file, dst_path + '/' + dst + '/' + file, self.is_public))

            zip_obj.close()

class Path:
    def __init__(self, finder:"Finder", user:str, name:str, path:str, type:str, is_public:bool=False) -> None:
        # 設定該路徑對應的用戶名稱、文件/文件夾名稱、路徑、完整路徑、是否公開、類型
        self.is_public = is_public
        self.finder = finder
        self.name = name
        self.path = path
        self.type = type
        self.content = None
        
        if is_public:
            self.user = None
            self.rootpath = './Netora/Storage/Public'
            self.location = ('/'.join(self.path.split('/')[:-1])).strip('/')
        else:
            self.user = user
            self.rootpath = './Netora/Storage/Personal/' + self.user
            self.location = ('/'.join(self.path.split('/')[:-1])).strip('/')
        
        self.fullpath = self.rootpath + '/' + self.path

        if not os.path.exists(self.fullpath):
            raise PathNotExists(f"{self.type.title()} - '{self.fullpath}' not exists")

    def rename(self, new_name:str):
        if not os.path.exists(self.rootpath + '/' + self.location + '/' + new_name):
            if self.type != P_ROOT:
                os.rename(self.fullpath, self.rootpath + '/' + self.location + '/' + new_name)
                self.name = new_name
                self.path = self.location + '/' + new_name

                self.fullpath = self.rootpath + '/' + self.location + '/' + self.name

                # 如果該類型為文件夾
                if self.type == P_FOLDER:
                    # 執行每個文件/文件夾的update_path函數進行更新路徑
                    for f in self.content:
                        f.update_path(self) 

            self.finder.save()
        else:
            raise PathAlreadyExists(f"{self.type.title()} - '{self.fullpath}' already exists")
        
    def update_path(self, folder:"Path"):
        if self.type != P_ROOT:
            self.path = folder.path + '/' + self.name
            self.fullpath = self.rootpath + '/' + self.path

            # 如果該類型為文件夾
            if self.type == P_FOLDER:
                # 執行每個文件/文件夾的update_path函數進行更新路徑
                for f in self.content:
                    f.update_path(self) 
        
    def remove(self):
        if self.type != P_ROOT:
            if self.type == P_FILE:
                os.remove(self.fullpath)
            else:
                shutil.rmtree(self.fullpath)

            if self.is_public:
                self.finder.findPublicByPath(self.location).content.remove(self)
            else:
                self.finder.findPersonalByPath(self.location).content.remove(self)

            self.finder.save()

    def find(self, name:str) -> "Path":
        pass

    def to_dict(self) -> dict:
        pass
    
class File(Path):
    def __init__(self, finder:"Finder", user: str, name: str, path: str, is_public: bool=False) -> None:
        super().__init__(finder, user, name, path, P_FILE, is_public)

    def to_dict(self):
        return {
            'name': self.name, 
            'type': self.type, 
            'path': self.path, 
        }

class Folder(Path):
    def __init__(self, finder:"Finder", user: str, name: str, path: str, content:dict, is_public: bool=False) -> None:
        super().__init__(finder, user, name, path, P_FOLDER, is_public)
        self.content = []
        for f in content.values():
            if f['type'] == P_FILE:
                self.content.append(File(finder, user, f['name'], f['path'], is_public))
            
            elif f['type'] == P_FOLDER:
                self.content.append(Folder(finder, user, f['name'], f['path'], f['content'], is_public))

    def add_data(self, data:Path):
        for c in self.content:
            if c.path == data.path:
                self.content.remove(c)

        self.content.append(data)
        self.finder.save()

    def save_file(self, files:list):
        saved_files = []
        for file in files:
            path = self.fullpath + '/' + file.filename
            file.save(path)
            file_obj = File(self.finder, self.user, file.filename, self.path + '/' + file.filename, self.is_public)

            for c in self.content:
                if c.path == file_obj.path:
                    self.content.remove(c)

            self.content.append(file_obj)
            saved_files.append(file_obj)

            self.finder.save()

        return saved_files

    def save_folder(self, folders:list):
        folder_objs = self.save_file(folders)
        for folder_obj in folder_objs:
            Zip(self.finder, folder_obj.user, folder_obj.path, self.is_public).extract()
            folder_obj.remove()

    def find(self, name:str) -> Path:
        return [f for f in self.content if f.name == name][0]

    def to_dict(self):
        return {
            'name': self.name, 
            'type': self.type, 
            'path': self.path, 
            'content': {f.name: f.to_dict() for f in self.content}
        }

class Root(Path):
    def __init__(self, finder:"Finder", user: str, content:dict, is_public: bool=False) -> None:
        super().__init__(finder, user, None, "", P_ROOT, is_public)
        self.content = []

        for f in content.values():
            if f['type'] == P_FILE:
                self.content.append(File(finder, user, f['name'], f['path'], is_public))
            
            elif f['type'] == P_FOLDER:
                self.content.append(Folder(finder, user, f['name'], f['path'], f['content'], is_public))

    def add_data(self, data:Path):
        for c in self.content:
            if c.path == data.path:
                self.content.remove(c)

        self.content.append(data)
        self.finder.save()

    def save_file(self, files:list):
        saved_files = []
        for file in files:
            path = self.fullpath + file.filename
            file.save(path)
            file_obj = File(self.finder, self.user, file.filename, self.path + '/' + file.filename, self.is_public)

            for c in self.content:
                if c.path == file_obj.path:
                    self.content.remove(c)

            self.content.append(file_obj)
            saved_files.append(file_obj)

            self.finder.save()

        return saved_files
        
    def save_folder(self, folders:list):
        folder_objs = self.save_file(folders)
        for folder_obj in folder_objs:
            Zip(self.finder, folder_obj.user, folder_obj.path, self.is_public).extract()
            folder_obj.remove()

    def find(self, name:str) -> Path:
        return [f for f in self.content if f.name == name][0]
    
    def to_dict(self):
        return {
            'user': self.user,
            'type': self.type,
            'content': {f.name: f.to_dict() for f in self.content}
        }

class Finder:
    with open("Netora/Users/users.json") as f:
        users = json.load(f)['users'].keys()

    def __init__(self, user:str, storage_file_path:str="Netora/Storage/storage.json") -> None:
        self.user = user
        self.storage_file_path = storage_file_path

        if os.path.exists(self.storage_file_path):
            with open(self.storage_file_path, 'r') as f:
                self.storage = json.load(f)

            self.personal_root = Root(self, user, self.storage['all-users'][self.user]['root']['content'])
            self.public_root = Root(self, None, self.storage['public']['root']['content'], True)

        else:
            raise PathNotExists(f"Storage - '{self.storage_file_path}' not exists")
        
    def findPersonalByName(self, name:str):
        return self.personal_root.find(name)
    
    def findPersonalByPath(self, path:str):
        obj = self.personal_root
        for f in path.split('/'):
            if f:
                obj = obj.find(f)
        return obj
    
    def findPublicByName(self, name:str):
        return self.public_root.find(name)
    
    def findPublicByPath(self, path:str):
        obj = self.public_root
        for f in path.split('/'):
            if f:
                obj = obj.find(f)
        return obj
        
    def to_dict(self):
        return self.personal_root.to_dict(), self.public_root.to_dict()
    
    def save(self):
        with open(self.storage_file_path, 'w') as f:
            self.storage['all-users'][self.user]['root'] = self.to_dict()[0]
            self.storage['public']['root'] = self.to_dict()[1]
            json.dump(self.storage, f, indent=4)

class PathNotExists(Exception):
    pass

class PathAlreadyExists(Exception):
    pass
