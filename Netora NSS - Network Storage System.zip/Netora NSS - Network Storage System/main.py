import Netora
import json
from flask import Flask

finder = Netora.Storage.Finder("user")

print(finder.findByPath('test3/test-folder2').remove())