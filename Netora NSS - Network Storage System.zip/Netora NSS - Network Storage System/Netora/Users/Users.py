import json
import os
import sys
import shutil

class Users:
    def __init__(self, users_file_path:str="Netora/Users/users.json") -> None:
        self.users_file_path = users_file_path
        
        if os.path.exists(self.users_file_path):
            with open(self.users_file_path, 'r') as f:
                self.users = json.load(f)
        else:
            raise PathNotExists(f"Path - '{self.users_file_path}' not exists")
        
    def get_user(self, username:str):
        if username in self.users['users']:
            return User(self, self.users['users'][username])
        
    def create_user(self, username:str, password:str, is_administrator:bool=False):
        self.users['users'][username] = {
            "username": username,
            "password": password,
            "is-administrator": is_administrator
        }
        os.makedirs(f'./Netora/Storage/Personal/{username}', exist_ok=True)

        with open(f'./Netora/Storage/storage.json', 'r') as f:
            data = json.load(f)

        data['all-users'][username] = {
            "root": {
                "user": "user",
                "type": "root",
                "content": {}
            }
        }

        with open(f'./Netora/Storage/storage.json', 'w') as f:
            json.dump(data, f, indent=4)

        self.save()

    def delete_user(self, username:str):
        del self.users['users'][username]
        shutil.rmtree(f'./Netora/Storage/Personal/{username}')
        self.save()
    
    def update_user(self, username:str, user:"User"):
        self.users['users'][user.username] = {
            "username": user.username,
            "password": user.password,
            "is-administrator": user.is_administrator
        }
        del self.users['users'][username]
        self.save()

    def save(self):
        with open(self.users_file_path, 'w') as f:
            json.dump(self.users, f, indent=4)

class User:
    def __init__(self, users:Users, user_data:dict) -> None:
        self.users = users
        self.username = user_data['username']
        self.password = user_data['password']
        self.is_administrator = user_data['is-administrator']

    def change_username(self, new_username:str):
        username = self.username
        self.username = new_username
        self.users.update_user(username, self)

    def change_password(self, new_password:str):
        username = self.username
        self.password = new_password
        self.users.update_user(username, self)

    def set_administrator(self, state:bool=True):
        username = self.username
        self.is_administrator = state
        self.users.update_user(username, self)

    def check(self, password:str):
        return self.password == password

class PathNotExists(Exception):
    pass