import json
import os
import sys
import shutil

class Users:
    def __init__(self, users_file_path:str="Netora/Users/users.json") -> None:
        self.users_file_path = users_file_path
        
        if os.path.exists(self.users_file_path):
            with open(self.users_file_path, 'r') as f:
                self.users = json.load(f)
        else:
            raise PathNotExists(f"Path - '{self.users_file_path}' not exists")
        
    def get_user(self, username:str):
        return User(self, self.users['users'][username])
    
    def update_user(self, username:str, user:"User"):
        self.users['users'][user.username] = {
            "username": user.username,
            "password": user.password,
            "is-administrator": user.is_administrator
        }

        del self.users[username]

class User:
    def __init__(self, users:Users, user_data:dict) -> None:
        self.users = users
        self.username = user_data['username']
        self.password = user_data['password']
        self.is_administrator = user_data['is-administrator']

    def change_username(self, new_username:str):
        username = self.username
        self.username = new_username
        self.users.update_user(username, self)

    def change_password(self, new_password:str):
        username = self.username
        self.password = new_password
        self.users.update_user(username, self)

    def set_administrator(self, state:bool=True):
        username = self.username
        self.is_administrator = state
        self.users.update_user(username, self)

class PathNotExists(Exception):
    pass