import json
import os
import sys
import shutil

T_USERNAME = 'username'
T_PASSWORD = 'password'
T_IS_ADMINISTRATOR = 'is-administrator'

class Users:
    def __init__(self, users_file_path:str="Netora/Users/users.json") -> None:
        self.users_file_path = users_file_path
        
        if os.path.exists(self.users_file_path):
            with open(self.users_file_path, 'r') as f:
                self.users = json.load(f)
        else:
            raise PathNotExists(f"Path - '{self.users_file_path}' not exists")
        
    def get_user(self, username:str):
        if username in self.users['users']:
            return User(self, self.users['users'][username])
        
    def create_user(self, username:str, password:str, is_administrator:bool=False):
        if username not in self.users['users']:
            self.users['users'][username] = {
                "username": username,
                "password": password,
                "is-administrator": is_administrator
            }
            os.makedirs(f'./Netora/Storage/Personal/{username}', exist_ok=True)

            with open(f'./Netora/Storage/storage.json', 'r') as f:
                data = json.load(f)

            data['all-users'][username] = {
                "root": {
                    "user": "user",
                    "type": "root",
                    "content": {}
                }
            }

            with open(f'./Netora/Storage/storage.json', 'w') as f:
                json.dump(data, f, indent=4)

            self.save()

            return (True, None)
        else:
            return (False, f"User '{username}' already exists")

    def delete_user(self, username:str):
        del self.users['users'][username]
        shutil.rmtree(f'./Netora/Storage/Personal/{username}')
        with open('./Netora/Storage/storage.json', 'r') as f:
            storage = json.load(f)
        del storage['all-users'][username]
        with open('./Netora/Storage/storage.json', 'w') as f:
            json.dump(storage, f, indent=4)
        self.save()
    
    def update_user(self, username:str, type:str, user:"User"):
        if user.username not in self.users['users'] or type != T_USERNAME:
            self.users['users'][user.username] = {
                "username": user.username,
                "password": user.password,
                "is-administrator": user.is_administrator
            }

            if type == T_USERNAME:
                del self.users['users'][username]

                os.rename(f'./Netora/Storage/Personal/{username}', f'./Netora/Storage/Personal/{user.username}')

                with open('./Netora/Storage/storage.json', 'r') as f:
                    storage = json.load(f)
                storage['all-users'][user.username] = storage['all-users'][username]
                del storage['all-users'][username]
                with open('./Netora/Storage/storage.json', 'w') as f:
                    json.dump(storage, f, indent=4)

            self.save()

            return (True, None)
        else:
            return (False, f"User '{user.username}' already exists")

    def save(self):
        with open(self.users_file_path, 'w') as f:
            json.dump(self.users, f, indent=4)

class User:
    def __init__(self, users:Users, user_data:dict) -> None:
        self.users = users
        self.username = user_data['username']
        self.password = user_data['password']
        self.is_administrator = user_data['is-administrator']

    def change_username(self, new_username:str):
        username = self.username
        self.username = new_username
        return self.users.update_user(username, T_USERNAME, self)

    def change_password(self, new_password:str):
        username = self.username
        self.password = new_password
        return self.users.update_user(username, T_PASSWORD, self)

    def set_administrator(self, state:bool=True):
        username = self.username
        self.is_administrator = state
        return self.users.update_user(username, T_IS_ADMINISTRATOR, self)

    def check(self, password:str):
        return self.password == password

class PathNotExists(Exception):
    pass