import json
import shutil
import os
import sys

P_FILE = 'file'
P_FOLDER = 'folder'
P_ROOT = 'root'

class Path:
    def __init__(self, finder:"Finder", user:str, name:str, path:str, type:str, is_public:bool=False) -> None:
        # 設定該路徑對應的用戶名稱、文件/文件夾名稱、路徑、完整路徑、是否公開、類型
        self.finder = finder
        self.user = user
        self.name = name
        self.path = path
        self.fullpath = './Netora/Storage/Personal/' + self.user + '/' + path
        self.set_public(is_public)
        self.type = type
        self.content = None

        if not os.path.exists(self.fullpath):
            raise PathNotExists(f"{self.type.title()} - '{self.fullpath}' not exists")
        
    def set_public(self, state:bool):
        if state:
            self.is_public = True

            if not any([True if f.path == self.path else False for f in self.finder.public]):
                self.finder.public.append(self)

        else:
            self.is_public = False

            for f in self.finder.public:
                if f.path == self.path:
                    self.finder.public.remove(f)

        if hasattr(self.finder, 'root'):
            self.finder.save()

    def rename(self, new_name:str):
        if not os.path.exists('./Netora/Storage/Personal/' + '/'.join(self.fullpath.split('/')[:-1]) + new_name):
            if self.type != P_ROOT:
                os.rename(self.fullpath, '/'.join(self.fullpath.split('/')[:-1]) + '/' + new_name)
                self.name = new_name
                self.path = ('/'.join(self.path.split('/')[:-1]) + '/' + self.name).strip('/')
                self.fullpath = './Netora/Storage/Personal/' + self.user + '/' + self.path

                # 如果該類型為文件夾
                if self.type == P_FOLDER:
                    # 執行每個文件/文件夾的update_path函數進行更新路徑
                    for f in self.content:
                        f.update_path(self) 

            self.finder.save()
        else:
            raise PathAlreadyExists(f"{self.type.title()} - '{self.fullpath}' already exists")
        
    def update_path(self, folder:"Path"):
        if self.type != P_ROOT:
            self.path = folder.path + '/' + self.name
            self.fullpath = './Netora/Storage/Personal/' + self.user + '/' + self.path

            # 如果該類型為文件夾
            if self.type == P_FOLDER:
                # 執行每個文件/文件夾的update_path函數進行更新路徑
                for f in self.content:
                    f.update_path(self) 
        
    def remove(self):
        if self.type != P_ROOT:
            if self.type == P_FILE:
                os.remove(self.fullpath)
            else:
                shutil.rmtree(self.fullpath)

            self.finder.findByPath('/'.join(self.path.split('/')[:-1]).strip('/')).content.remove(self)

            self.finder.save()

    def find(self, name:str) -> "Path":
        pass

    def to_dict(self) -> dict:
        pass
    
class File(Path):
    def __init__(self, finder:"Finder", user: str, name: str, path: str, is_public: bool = False) -> None:
        super().__init__(finder, user, name, path, P_FILE, is_public)

    def to_dict(self):
        return {
            'name': self.name, 
            'type': self.type, 
            'path': self.path, 
            'is-public': self.is_public
        }

class Folder(Path):
    def __init__(self, finder:"Finder", user: str, name: str, path: str, content:dict, is_public: bool = False) -> None:
        super().__init__(finder, user, name, path, P_FOLDER, is_public)
        self.content = []
        for f in content.values():
            if f['type'] == P_FILE:
                self.content.append(File(finder, user, f['name'], f['path'], f['is-public']))
            
            elif f['type'] == P_FOLDER:
                self.content.append(Folder(finder, user, f['name'], f['path'], f['content'], f['is-public']))

    def save_file(self, files:list):
        for file in files:
            path = self.fullpath + '/' + file.filename
            file.save(path)
            self.content.append(File(self.finder, self.user, file.filename, path))

            self.finder.save()

    def find(self, name:str) -> Path:
        return [f for f in self.content if f.name == name][0]

    def to_dict(self):
        return {
            'name': self.name, 
            'type': self.type, 
            'path': self.path, 
            'is-public': self.is_public, 
            'content': {f.name: f.to_dict() for f in self.content}
        }

class Root(Path):
    def __init__(self, finder:"Finder", user: str, content:dict) -> None:
        super().__init__(finder, user, None, "", P_ROOT, False)
        self.content = []

        for f in content.values():
            if f['type'] == P_FILE:
                self.content.append(File(finder, user, f['name'], f['path'], f['is-public']))
            
            elif f['type'] == P_FOLDER:
                self.content.append(Folder(finder, user, f['name'], f['path'], f['content'], f['is-public']))

    def save_file(self, files:list):
        for file in files:
            path = self.fullpath + file.filename
            file.save(path)
            self.content.append(File(self.finder, self.user, file.filename, self.path + file.filename))

            self.finder.save()

    def find(self, name:str) -> Path:
        return [f for f in self.content if f.name == name][0]
    
    def to_dict(self):
        return {
            'user': self.user,
            'type': self.type,
            'content': {f.name: f.to_dict() for f in self.content}
        }

class Finder:
    with open("Netora/Users/users.json") as f:
        users = json.load(f)['users'].keys()

    public = []

    def __init__(self, user:str, storage_file_path:str="Netora/Storage/storage.json") -> None:
        self.user = user
        self.storage_file_path = storage_file_path

        if os.path.exists(self.storage_file_path):
            with open(self.storage_file_path, 'r') as f:
                self.storage = json.load(f)

            self.root = Root(self, user, self.storage['all-users'][self.user]['root']['content'])

        else:
            raise PathNotExists(f"Storage - '{self.storage_file_path}' not exists")
        
    def findByName(self, name:str):
        return self.root.find(name)
    
    def findByPath(self, path:str):
        obj = self.root
        for f in path.split('/'):
            if f:
                obj = obj.find(f)
        return obj
        
    def to_dict(self):
        return self.root.to_dict()
    
    def save(self):
        with open(self.storage_file_path, 'w') as f:
            self.storage['all-users'][self.user]['root'] = self.to_dict()
            json.dump(self.storage, f, indent=4)

for user in Finder.users:
    Finder(user)

class PathNotExists(Exception):
    pass

class PathAlreadyExists(Exception):
    pass