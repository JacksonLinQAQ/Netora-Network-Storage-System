import json
import shutil

class Settings:
    def __init__(self, settings_file_path:str='./Netora/Settings/config.json') -> None:
        self.settings_file_path = settings_file_path
        with open(settings_file_path, 'r') as f:
            self.settings = json.load(f)

    def change_setting(self, setting:str, value):
        self.settings[setting] = value
        self.save()

    def get_setting(self, setting:str):
        return self.settings[setting]
    
    def reset(self):
        self.settings = {
            "setup": False,
            "system-name": None,
            "create-user": False
        }

        self.save()
    
    def save(self):
        with open(self.settings_file_path, 'w') as f:
            json.dump(self.settings, f, indent=4)