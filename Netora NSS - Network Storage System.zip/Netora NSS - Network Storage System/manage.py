from sys import argv
from Netora import *
import os
import shutil
import json
import requests
import socket

try:
    req = requests.get(f'http://{socket.gethostbyname(socket.gethostname())}:{3000}/server-authentication')
    print("Please make sure the 'app.py' Netora system server is stopped")

except requests.exceptions.ConnectionError:
    if len(argv) > 1:
        if argv[1] == 'users':
            if argv[2] == 'set':
                if argv[3] == 'username':
                    user = argv[4]
                    new_username = argv[5]

                    if user in users.Users().users['users']:
                        result = users.Users().get_user(user).change_username(new_username)

                        if result[0]:
                            print(f"User '{user}' set username to '{new_username}'")
                        else:
                            print(result[1])

                if argv[3] == 'password':
                    user = argv[4]
                    new_password = argv[5]

                    if user in users.Users().users['users']:
                        result = users.Users().get_user(user).change_password(new_password)

                        if result[0]:
                            print(f"User '{user}' set password to '{new_password}'")
                        else:
                            print(result[1])

                if argv[3] == 'is-admin':
                    user = argv[4]
                    state = bool(int(argv[5]))

                    if user in users.Users().users['users']:
                        users.Users().get_user(user).set_administrator(state)
                        print(f"User '{user}' set adminstrator to '{state}'")

                    else:
                        print(f"User '{user}' not exists")

            if argv[2] == 'find':
                if argv[3] == 'password':
                    user = argv[4]

                    if user in users.Users().users['users']:
                        print(f"User '{user}' 's password is '{users.Users().get_user(user).password}'")

                    else:
                        print(f"User '{user}' not exists")

                if argv[3] == 'is-admin':
                    user = argv[4]

                    if user in users.Users().users['users']:
                        if users.Users().get_user(user).is_administrator:
                            print(f"User '{user}' is an administrator")
                        else:
                            print(f"User '{user}' isn't an administrator")

                    else:
                        print(f"User '{user}' not exists")

            if argv[2] == 'del':
                user = argv[3]

                if user in users.Users().users['users']:
                    users.Users().delete_user(user)
                    print(f"User '{user}' deleted")

                else:
                    print(f"User '{user}' not exists")

            if argv[2] == 'create':
                username = argv[3]
                password = argv[4]
                is_administrator = bool(int(argv[5]))

                if username not in users.Users().users['users']:
                    users.Users().create_user(username, password, is_administrator)
                    print(f"User '{username}' created")

                else:
                    print(f"User '{username}' already exists")

        elif argv[1] == 'system':
            if argv[2] == 'reset':
                print("The system is reseting now")
                all_users = users.Users()
                for user in [user for user in all_users.users['users']]:
                    all_users.delete_user(user)

                with open('Netora/Storage/storage.json', 'w') as f:
                    json.dump({
                        "all-users": {},
                        "public": {
                            "root": {
                                "user": None,
                                "type": "root",
                                "content": {}
                            }
                        }
                    }, f, indent=4)

                shutil.rmtree('Netora/Storage/Personal')
                shutil.rmtree('Netora/Storage/Public')
                os.makedirs('Netora/Storage/Personal')
                os.makedirs('Netora/Storage/Public')
                settings.Settings().reset()

                print("The system has been reset")

    else:
        print(
            "[Netora Network Storage System Manager]",
            "",
            "<user>/<username> => username",
            "<password> => password",
            "<is-admin> => is administrator <state>",
            "<new-username>/<new-password> => a new username or password",
            "<state> => (0/1)",
            "<none> => nothing",
            "",
            "Commands:",
            "--------------------",
            "users",
            " - set",
            "    username <user> <new-username> => <none>",
            "    password <user> <new-password> => <none>",
            "    is-admin <user> <state:is-admin> => <none>",
            " - find",
            "    password <user> => <password>",
            "    is-admin <user> => <state:is-admin>",
            " - del <user> => none",
            " - create <username> <password> <is-admin> => <none>",
            "",
            "system",
            " - reset => <none>",
            sep='\n',
            end='\n\n'
        )