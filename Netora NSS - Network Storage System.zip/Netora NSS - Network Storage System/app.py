import Netora
import json
import socket
from flask import Flask, render_template, send_file, url_for, request, redirect

app = Flask(__name__)

logged_in_user = {}

@app.route('/')
@app.route('/index')
def index():
    return render_template("index.html")

@app.route('/login')
def login():
    if logged_in_user.get(request.remote_addr):
        return redirect('./personal')
    else:
        return render_template("login.html")
    
@app.route('/logout')
def logout():
    if logged_in_user.get(request.remote_addr):
        del logged_in_user[request.remote_addr]
    return redirect('./login')

@app.route('/personal', methods=["GET", "POST"])
def personal():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            return render_template("personal.html", user=logged_in_user.get(request.remote_addr), files=list(Netora.storage.Finder(logged_in_user.get(request.remote_addr).get('user')).findByPath('').to_dict()['content'].values()))
        
        else:
            return redirect('./login')

    elif request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user_obj = Netora.users.Users()
        user = user_obj.get_user(username)
        if user and user.check(password):
            logged_in_user.update({
                request.remote_addr: {
                    'user': username
                }
            })

            return redirect('./personal')

        else:
            return "Incorrect username or password"

app.run(socket.gethostbyname(socket.gethostname()), 3000, True)