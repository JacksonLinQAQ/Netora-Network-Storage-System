import Netora
import json
import socket
from flask import Flask, render_template, send_file, url_for, request, redirect

app = Flask(__name__)

logged_in_user = {}

@app.route('/')
@app.route('/index')
def index():
    return render_template("index.html")

@app.route('/login')
def login():
    if logged_in_user.get(request.remote_addr):
        return redirect('./personal?path=')
    else:
        return render_template("login.html")
    
@app.route('/logout')
def logout():
    if logged_in_user.get(request.remote_addr):
        del logged_in_user[request.remote_addr]
    return redirect('./login')

@app.route('/personal', methods=["GET", "POST"])
def personal():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            if not path:
                path = ''

            path_obj = Netora.storage.Finder(logged_in_user.get(request.remote_addr).get('user')).findByPath(path)

            if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
                return render_template("personal.html", user=logged_in_user.get(request.remote_addr), files=list(path_obj.to_dict()['content'].values()), path=path, previous_path='/'.join(path.split()[:-1]))
            elif path_obj.type == Netora.storage.P_FILE:
                return send_file(path_obj.fullpath.replace('/', '\\'))
            else:
                return "Path Not Found"
        
        else:
            return redirect('./login')

    elif request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user_obj = Netora.users.Users()
        user = user_obj.get_user(username)
        if user and user.check(password):
            logged_in_user.update({
                request.remote_addr: {
                    'user': username
                }
            })

            return redirect('./personal?path=')

        else:
            return "Incorrect username or password"
        
@app.route('/upload-files', methods=["GET", "POST"])
def upload_files():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            return render_template("upload-files.html", user=logged_in_user.get(request.remote_addr), path=path)
        else:
            return redirect('./login')
        
    elif request.method == 'POST':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            files = request.files.getlist('file')
            if files:
                user = logged_in_user[request.remote_addr]
                path_obj = Netora.storage.Finder(user.get('user')).findByPath(path)
                if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
                    path_obj.save_file(files)

            return redirect(f'./personal?path={path}')
        else:
            return redirect('./login')

app.run(socket.gethostbyname(socket.gethostname()), 3000, True)