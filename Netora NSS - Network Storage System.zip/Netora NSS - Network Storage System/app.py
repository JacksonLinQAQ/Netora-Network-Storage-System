import Netora
import json
import socket
from flask import Flask, render_template, send_file, url_for, request, redirect

app = Flask(__name__)

logged_in_user = {}

@app.route('/')
@app.route('/index')
def index():
    if Netora.settings.Settings().get_setting('setup'):
        return render_template("index.html")
    else:
        return redirect('./setup/welcome')

@app.route('/login')
def login():
    if Netora.settings.Settings().get_setting('setup'):
        if logged_in_user.get(request.remote_addr):
            return redirect('./personal?path=')
        else:
            return render_template("login.html")
    else:
        return redirect('./setup/welcome')
    
@app.route('/logout')
def logout():
    if logged_in_user.get(request.remote_addr):
        del logged_in_user[request.remote_addr]
    return redirect('./login')

@app.route('/personal', methods=["GET", "POST"])
def personal():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            if not path:
                path = ''

            path_obj = Netora.storage.Finder(logged_in_user.get(request.remote_addr).get('user')).findPersonalByPath(path)

            if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
                return render_template("personal.html", user=logged_in_user.get(request.remote_addr), files=list(path_obj.to_dict()['content'].values()), path=path, previous_path='/'.join(path.split('/')[:-1]), is_administrator=Netora.users.Users().get_user(logged_in_user.get(request.remote_addr).get('user')).is_administrator)
            elif path_obj.type == Netora.storage.P_FILE:
                return send_file(path_obj.fullpath.replace('/', '\\'))
            else:
                return "Path Not Found"
        
        else:
            return redirect('./login')

    elif request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user_obj = Netora.users.Users()
        user = user_obj.get_user(username)
        if user and user.check(password):
            logged_in_user.update({
                request.remote_addr: {
                    'user': username
                }
            })

            return redirect('./personal?path=')

        else:
            return "Incorrect username or password"
        
@app.route('/public', methods=["GET", "POST"])
def public():
    if logged_in_user.get(request.remote_addr):
        path = request.args.get('path')
        if not path:
            path = ''

        path_obj = Netora.storage.Finder(logged_in_user.get(request.remote_addr).get('user')).findPublicByPath(path)

        if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
            return render_template("public.html", user=logged_in_user.get(request.remote_addr), files=list(path_obj.to_dict()['content'].values()), path=path, previous_path='/'.join(path.split('/')[:-1]), is_administrator=Netora.users.Users().get_user(logged_in_user.get(request.remote_addr).get('user')).is_administrator)
        elif path_obj.type == Netora.storage.P_FILE:
            return send_file(path_obj.fullpath.replace('/', '\\'))
        else:
            return "Path Not Found"
    
    else:
        return redirect('./login')
    
# 個人空間
        
@app.route('/download-personal-file')
def download_personal_file():
    if logged_in_user.get(request.remote_addr):
        path = request.args.get('path')
        user = logged_in_user[request.remote_addr]
        path_obj = Netora.storage.Finder(user.get('user')).findPersonalByPath(path)
        if path_obj.type == Netora.storage.P_FILE:
            return send_file(path_obj.fullpath, as_attachment=True)
    else:
        return redirect('./login')
    
@app.route('/upload-personal-files', methods=["GET", "POST"])
def upload_personal_files():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            return render_template("upload-files.html", user=logged_in_user.get(request.remote_addr), path=path, upload_link="/upload-personal-files")
        else:
            return redirect('./login')
        
    elif request.method == 'POST':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            files = request.files.getlist('file')
            if files:
                user = logged_in_user[request.remote_addr]
                path_obj = Netora.storage.Finder(user.get('user')).findPersonalByPath(path)
                if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
                    path_obj.save_file(files)

            return redirect(f'./personal?path={path}')
        else:
            return redirect('./login')
        
@app.route('/upload-personal-folders', methods=["GET", "POST"])
def upload_personal_folders():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            return render_template("upload-folders.html", user=logged_in_user.get(request.remote_addr), path=path, upload_link="/upload-personal-folders")
        else:
            return redirect('./login')
        
    elif request.method == 'POST':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            files = request.files.getlist('file')
            if files:
                user = logged_in_user[request.remote_addr]
                path_obj = Netora.storage.Finder(user.get('user')).findPersonalByPath(path)
                if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
                    path_obj.save_folder(files)

            return redirect(f'./personal?path={path}')
        else:
            return redirect('./login')
    
@app.route('/delete-personal')
def delete_personal():
    if logged_in_user.get(request.remote_addr):
        path = request.args.get('path')
        user = logged_in_user[request.remote_addr]
        path_obj = Netora.storage.Finder(user.get('user')).findPersonalByPath(path)
        path_obj.remove()
        return redirect(f'./personal?path={"/".join(path.split("/")[:-1])}')
    else:
        return redirect('./login')
        
# 公共空間
        
@app.route('/download-public-file')
def download_public_file():
    if logged_in_user.get(request.remote_addr):
        path = request.args.get('path')
        user = logged_in_user[request.remote_addr]
        path_obj = Netora.storage.Finder(user.get('user')).findPublicByPath(path)
        if path_obj.type == Netora.storage.P_FILE:
            return send_file(path_obj.fullpath, as_attachment=True)
    else:
        return redirect('./login')
    
@app.route('/upload-public-files', methods=["GET", "POST"])
def upload_public_files():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            return render_template("upload-files.html", user=logged_in_user.get(request.remote_addr), path=path, upload_link="/upload-public-files")
        else:
            return redirect('./login')
        
    elif request.method == 'POST':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            files = request.files.getlist('file')
            if files:
                user = logged_in_user[request.remote_addr]
                path_obj = Netora.storage.Finder(user.get('user')).findPublicByPath(path)
                if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
                    path_obj.save_file(files)

            return redirect(f'./public?path={path}')
        else:
            return redirect('./login')
        
@app.route('/upload-public-folders', methods=["GET", "POST"])
def upload_public_folders():
    if request.method == 'GET':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            return render_template("upload-folders.html", user=logged_in_user.get(request.remote_addr), path=path, upload_link="/upload-public-folders")
        else:
            return redirect('./login')
        
    elif request.method == 'POST':
        if logged_in_user.get(request.remote_addr):
            path = request.args.get('path')
            files = request.files.getlist('file')
            if files:
                user = logged_in_user[request.remote_addr]
                path_obj = Netora.storage.Finder(user.get('user')).findPublicByPath(path)
                if path_obj.type == Netora.storage.P_FOLDER or path_obj.type == Netora.storage.P_ROOT:
                    path_obj.save_folder(files)

            return redirect(f'./public?path={path}')
        else:
            return redirect('./login')
    
@app.route('/delete-public')
def delete_public():
    if logged_in_user.get(request.remote_addr):
        path = request.args.get('path')
        user = logged_in_user[request.remote_addr]
        path_obj = Netora.storage.Finder(user.get('user')).findPublicByPath(path)
        path_obj.remove()
        return redirect(f'./public?path={"/".join(path.split("/")[:-1])}')
    else:
        return redirect('./login')
    
# 管理員設置

@app.route('/admin-settings')
def admin_settings():
    if logged_in_user.get(request.remote_addr):
        path = request.args.get('path')
        user = logged_in_user[request.remote_addr]
        is_administrator = Netora.users.Users().get_user(user.get('user')).is_administrator
        if is_administrator:
            return render_template('admin.html', users=Netora.users.Users().users['users'], current_user=user, is_administrator=is_administrator, system_name=Netora.settings.Settings().get_setting('system-name'))
        else:
            return "Your current account does not have permission to access this page"
    else:
        return redirect('./login')
    
# 更改用戶名稱/密碼

@app.route('/change-username', methods=['POST'])
def change_username():
    if logged_in_user.get(request.remote_addr):
        if Netora.users.Users().get_user(logged_in_user.get(request.remote_addr).get('user')).is_administrator:
            user = request.args.get('user')
            new_username = request.form['new-username']
            result = Netora.users.Users().get_user(user).change_username(new_username)
            if result[0]:
                if user == logged_in_user.get(request.remote_addr).get('user'):
                    del logged_in_user[request.remote_addr]
                    return redirect('./login')
                else:
                    return redirect('./admin-settings')
            else:
                return result[1]
        else:
            return "Your current account does not have permission to do this action"
    else:
        return redirect('./login')

@app.route('/change-password', methods=['POST'])
def change_password():
    if logged_in_user.get(request.remote_addr):
        if Netora.users.Users().get_user(logged_in_user.get(request.remote_addr).get('user')).is_administrator:
            user = request.args.get('user')
            new_password = request.form['new-password']
            confirm_password = request.form['confirm-password']
            if new_password == confirm_password:
                Netora.users.Users().get_user(user).change_password(new_password)
                if user == logged_in_user.get(request.remote_addr).get('user'):
                    del logged_in_user[request.remote_addr]
                    return redirect('./login')
                else:
                    return redirect('./admin-settings')
            else:
                return "Confirm password not match"
        else:
            return "Your current account does not have permission to do this action"
    else:
        return redirect('./login')
    
# 添加/刪除用戶

@app.route('/create-user', methods=['POST'])
def create_user():
    if logged_in_user.get(request.remote_addr):
        if Netora.users.Users().get_user(logged_in_user.get(request.remote_addr).get('user')).is_administrator:
            username = request.form['username']
            password = request.form['password']
            confirm_passsword = request.form['confirm-password']

            result = Netora.users.Users().create_user(username, password, False)

            if result[0]:
                return redirect('./admin-settings')
            else:
                return result[1]
        else:
            return "Your current account does not have permission to do this action"
    else:
        return redirect('./login')

@app.route('/delete-user')
def delete_user():
    if logged_in_user.get(request.remote_addr):
        if Netora.users.Users().get_user(logged_in_user.get(request.remote_addr).get('user')).is_administrator:
            user = request.args.get('user')
            Netora.users.Users().delete_user(user)
            for u in logged_in_user:
                if logged_in_user[u]['user'] == user:
                    del logged_in_user[u]
            return redirect('./admin-settings')
        else:
            return "Your current account does not have permission to do this action"
    else:
        return redirect('./login')
    
# 系統初始化

@app.route('/setup/<process>', methods=['GET', 'POST'])
def setup(process):
    if request.method == 'GET':
        if process == 'welcome':
            return render_template('setup/welcome.html') 
        elif process == 'system-name':
            if not Netora.settings.Settings().get_setting('system-name'):
                return render_template('setup/system-name.html')
            else:
                return redirect('./create-user')
        elif process == 'create-user':
            if not Netora.settings.Settings().get_setting('create-user'):
                return render_template('setup/create-user.html')

    elif request.method == 'POST':
        if process == 'system-name':
            system_name = request.form['system-name']
            if system_name:
                Netora.settings.Settings().change_setting('system-name', system_name)
                return redirect('./create-user')
            else:
                return "Please enter a system name"
            
        elif process == 'create-user':
            username = request.form['username']
            password = request.form['password']
            confirm_password = request.form['confirm-password']

            if username and password:
                if password == confirm_password:
                    Netora.users.Users().create_user(username, password, True)
                    Netora.settings.Settings().change_setting('create-user', True)
                    Netora.settings.Settings().change_setting('setup', True)
                    return redirect('../')
                else:
                    return "Confirm password not match"
            else:
                return "Username and password cannot be empty"
    
# 啓動服務器驗證

@app.route('/server-authentication')
def server_authentication():
    return f"Server is running on '{socket.gethostbyname(socket.gethostname())}:{3000}'"

app.run(socket.gethostbyname(socket.gethostname()), 3000, True)