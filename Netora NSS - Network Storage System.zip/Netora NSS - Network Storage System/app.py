import Netora
import json
import socket
from flask import Flask, render_template, send_file, url_for, request

app = Flask(__name__)

logged_in_user = {}

@app.route('/')
@app.route('/index')
def index():
    return render_template("index.html")

app.run(socket.gethostbyname(socket.gethostname()), 3000, True)